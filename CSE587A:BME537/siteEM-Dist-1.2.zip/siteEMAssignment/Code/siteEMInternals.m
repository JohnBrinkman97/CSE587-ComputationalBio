(* Put your code for sequencePosteriors, updateMotifPrior, and updatePFMCounts,
   along with any other functions you write to implement them, in this file.
   Don't forget that you can use your implementation of sitePosterior as part of your
   implementation of sequencePosteriors or, if you prefer, you can request a correct
   version from the TAs. *)
sequencePosteriors[sequence_, sitePrior_, siteProbs_, backgroundProbs_] :=
	Module[{},
	    
	]
	
updateMotifPrior[normalizedPosteriors_] := 
	Module[{},
	    
	]
	
updatePFMCounts[motifLength_, input_, normalizedPosteriors_, motifPseudocounts_, erasers_] :=
	Module[{},
	    
	]

(* Put your code for sitePosterior here. *)
sitePosterior[sequence_, sitePrior_, backgroundPrior_, siteProbs_, backgroundProbs_] := 
	Module[{},
	    
	]