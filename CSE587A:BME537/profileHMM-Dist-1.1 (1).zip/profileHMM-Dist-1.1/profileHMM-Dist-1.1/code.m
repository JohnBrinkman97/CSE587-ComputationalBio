 <<tools`
 
createPHMM[msaFile_]:=
	Module[{sequences, matches, matchStates, numMatch, pHMM, i},
		(*read in the msaFile*)
		sequences = parsingMSA[msaFile];
		(*determine which positions in the sequences are match states*)
		matches = Select[Map[Select[#, StringQ] &, Transpose[sequences]], Length[#] < Length[sequences]/2 &];
		matchStates = Sort[DeleteDuplicates[Flatten[Map[Position[Map[Select[#, StringQ] &, Transpose[sequences]], #] &, matches]]]];
		numMatch = Length[matchStates];
		(*get skeleton PHMM, assuming alphabet is DNA (4 letters)*)
		pHMM=skeletonPHMM[numMatch, 4];
		(*loop through all sequences, updating the PHMM counts*)
		For[i=1, i<=Length[sequences], i++,
			pHMM=updatePHMM[sequences[[i]], matchStates, pHMM]
		];
		(*normalize the PHMM counts to return PHMM probabilities*)
		normalizePHMM[pHMM]
	]

(*
Reminder about the PHMM structure:
Insert0 state emission probabilities (list length = length of alphabet)
Transition probabilities for B -> M1, B -> I0, B -> D1; I0 -> M1, I0 -> I0
A 3 D emission array, 
	where the first level corresponds to the index of the states (so if we have 10 match states, we expect length of 10 for the emission array), 
	the second level corresponds to the state type (Insert, or Match, so we expect length of 2 for the emission subarrays), 
	and the last level corresponds to the alphabet emission probabilities (so for the DNA alphabet, we expect length of 4 for the emission sub - subarray)
A 2 D transition array, 
	where the first level corresponds to the index of the the states (so if we have 10 match states, we expect length of 10 for the transition array), 
	and the second level corresponds to the transition probabilities to the next states 
		(so we expect 7 values for each subarray in the transition array corresponding to 
		Mk -> Mk + 1, Mk -> Ik, Mk -> Dk + 1; Ik -> Mk + 1, Ik -> Ik; Dk -> Mk + 1, Dk -> Dk + 1)

update PHMM pseudocounts based on given sequence
*)
updatePHMM[sequence_, matchStates_, pHMM_]:=
	Module[{pHMMIndex, currentState, sequenceIndex,
		initialInsertEmissions, initialTransitions, emissions, transitions},
		
		{initialInsertEmissions, initialTransitions, emissions, transitions}=pHMM;
		
		(*
		Walk through given sequence.
		Note that transitions up to the first match state will update the initial transitions list of the PHMM
		All following transitions will update the 2D transitions array
		*)
	
		(*Update the transitions into the end state (Mk+1)*)

		(*return updated pseudocounts*)
		{initialInsertEmissions, initialTransitions, emissions, transitions}
	]
	
	
(*Normalize the parts of the PHMM to get probability values instead of counts
Keep in mind that probabilities should not add up to one for every sublist, but rather for:
	transitions out of the same state
	emissions from the same state
*)
normalizePHMM[{initialInsertEmissions_, initialTransitions_, emissions_, transitions_}]:=
	Module[{normalizedInitialInsertEmissions, normalizedInitialTransitions, normalizedEmissions, normalizedTransitions},
	
	
	
		(*Return the normalized PHMM*)
		{normalizedInitialInsertEmissions, normalizedInitialTransitions, normalizedEmissions, normalizedTransitions}
	]